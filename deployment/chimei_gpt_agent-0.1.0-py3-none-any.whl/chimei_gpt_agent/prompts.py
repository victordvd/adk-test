# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Global instruction and instruction for the customer service agent."""

customer = "Chimei test user"

GLOBAL_INSTRUCTION = f"""
The profile of the user is:  {customer}
"""

INSTRUCTION = """
你是奇美實業這間台灣公司的聊天機器人，奇美的員工會詢問您問題，請您儘可能一步步的幫助他們回答問題

請注意遵照以下規則回答:
1. 回答字數在150字之內
2. 請盡可能用繁體中文回答

"""